﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class wh_frmAssinment1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(wh_frmAssinment1))
        Me.btnMissions = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.lblMissions = New System.Windows.Forms.Label()
        Me.picMissionary = New System.Windows.Forms.PictureBox()
        Me.picStudentImage = New System.Windows.Forms.PictureBox()
        Me.txtVerse = New System.Windows.Forms.TextBox()
        CType(Me.picMissionary, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStudentImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnMissions
        '
        Me.btnMissions.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.btnMissions.Location = New System.Drawing.Point(22, 381)
        Me.btnMissions.Name = "btnMissions"
        Me.btnMissions.Size = New System.Drawing.Size(106, 39)
        Me.btnMissions.TabIndex = 0
        Me.btnMissions.Text = "&Missions"
        Me.btnMissions.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(674, 381)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(105, 39)
        Me.btnQuit.TabIndex = 1
        Me.btnQuit.Text = "&Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'lblMissions
        '
        Me.lblMissions.AutoSize = True
        Me.lblMissions.Font = New System.Drawing.Font("Segoe MDL2 Assets", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMissions.ForeColor = System.Drawing.SystemColors.Control
        Me.lblMissions.Location = New System.Drawing.Point(294, 324)
        Me.lblMissions.Name = "lblMissions"
        Me.lblMissions.Size = New System.Drawing.Size(233, 96)
        Me.lblMissions.TabIndex = 2
        Me.lblMissions.Text = "Operation Mobilization USA" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "William Harkley" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Miranda Dyer" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "11/02/2020"
        Me.lblMissions.Visible = False
        '
        'picMissionary
        '
        Me.picMissionary.Image = Global.Wharkley_Assignment1.My.Resources.Resources.missionary_mike
        Me.picMissionary.Location = New System.Drawing.Point(518, 73)
        Me.picMissionary.Name = "picMissionary"
        Me.picMissionary.Size = New System.Drawing.Size(261, 211)
        Me.picMissionary.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMissionary.TabIndex = 4
        Me.picMissionary.TabStop = False
        Me.picMissionary.Visible = False
        '
        'picStudentImage
        '
        Me.picStudentImage.Image = Global.Wharkley_Assignment1.My.Resources.Resources.Paul_the_missionary
        Me.picStudentImage.Location = New System.Drawing.Point(37, 40)
        Me.picStudentImage.Name = "picStudentImage"
        Me.picStudentImage.Size = New System.Drawing.Size(226, 306)
        Me.picStudentImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picStudentImage.TabIndex = 3
        Me.picStudentImage.TabStop = False
        '
        'txtVerse
        '
        Me.txtVerse.BackColor = System.Drawing.SystemColors.WindowText
        Me.txtVerse.Font = New System.Drawing.Font("Sitka Heading", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVerse.ForeColor = System.Drawing.SystemColors.Control
        Me.txtVerse.Location = New System.Drawing.Point(298, 63)
        Me.txtVerse.Multiline = True
        Me.txtVerse.Name = "txtVerse"
        Me.txtVerse.Size = New System.Drawing.Size(185, 244)
        Me.txtVerse.TabIndex = 5
        Me.txtVerse.TabStop = False
        Me.txtVerse.Text = resources.GetString("txtVerse.Text")
        Me.txtVerse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'wh_frmAssinment1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.WindowText
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtVerse)
        Me.Controls.Add(Me.picMissionary)
        Me.Controls.Add(Me.picStudentImage)
        Me.Controls.Add(Me.lblMissions)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnMissions)
        Me.Name = "wh_frmAssinment1"
        Me.Text = "Assignment 1"
        CType(Me.picMissionary, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStudentImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnMissions As Button
    Friend WithEvents btnQuit As Button
    Friend WithEvents lblMissions As Label
    Friend WithEvents picStudentImage As PictureBox
    Friend WithEvents picMissionary As PictureBox
    Friend WithEvents txtVerse As TextBox
End Class
