﻿Public Class wh_frmAssinment1
    'Name: wh_frmAssignment1
    'Purpose: To share the purpose of missionary work and encourage others to contribute
    'Programmer: William Harkley
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblMissions_Click(sender As Object, e As EventArgs) Handles lblMissions.Click
        'I am hiding the label until the missions button is clicked
        lblMissions.Hide()

    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        'this button closes the app when clicked
        Close()

    End Sub

    Private Sub btnMissions_Click(sender As Object, e As EventArgs) Handles btnMissions.Click
        'this button shows the label and missionary picture simultaneously
        lblMissions.Show()
        picMissionary.Show()

    End Sub

    Private Sub txtVerse_TextChanged(sender As Object, e As EventArgs) Handles txtVerse.TextChanged

    End Sub

    Private Sub picStudentImage_Click(sender As Object, e As EventArgs) Handles picStudentImage.Click

    End Sub

    Private Sub picMissionary_Click(sender As Object, e As EventArgs) Handles picMissionary.Click
        'this hides the missionary picture until the missionary button is clicked.
        picMissionary.Hide()

    End Sub
End Class
